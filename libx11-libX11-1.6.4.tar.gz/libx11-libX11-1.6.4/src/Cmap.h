
#ifndef _CMAP_H_
#define _CMAP_H_

#include <X11/Xlib.h>

extern void
_XcmsDeleteCmapRec(
    Display *dpy,
    Colormap cmap);

#endif /* _CMAP_H_ */
